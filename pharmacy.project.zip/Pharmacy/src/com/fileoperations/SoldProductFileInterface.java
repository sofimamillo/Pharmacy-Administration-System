package com.fileoperations;
import java.util.ArrayList;

public interface SoldProductFileInterface {
	
    public void saveSoldProduct(SoldProduct soldProduct);
    public ArrayList<SoldProduct> getSoldProductsByBillID();
    public ArrayList<SoldProduct> getSoldProducts();
    public ArrayList<SoldProduct> getSoldProductsByDate(String date1, String date2);

}
