package com.fileoperations;
import java.io.*;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class ProductFile implements ProductFileInterface {
	
    private final String fileName = "product.txt"; 

    public ArrayList<Product> getProductsByDate(String date1, String date2){
        ArrayList<Product> products = new ArrayList<>();
        File file = new File(fileName);
        
        if (!file.exists()) {
            System.err.println("Database file not found at: " + file.getAbsolutePath());
            return products;
        }

        try (Scanner scanner = new Scanner(file).useLocale(Locale.US)) {
            if (scanner.hasNextLine()) scanner.nextLine(); // Skip Header

            while (scanner.hasNext()) {
                try {
                    int id = scanner.nextInt();
                    String name = scanner.next();
                    double sellingPrice = scanner.nextDouble();
                    int quantity = scanner.nextInt();
                    int supplierId = scanner.nextInt();
                    double boughtPrice = scanner.nextDouble();
                    String dateStr = scanner.next();

                    Product product = new Product();
                    setProductValues(product, id, name, sellingPrice, quantity, supplierId, boughtPrice, new DateForFile(dateStr));
                    
                    String billDate = product.getBoughtDate().toFileDate();
                    // Robust string comparison for dates (YYYY-MM-DD)
                    if(billDate.compareTo(date1) >= 0 && billDate.compareTo(date2) <= 0){
                        products.add(product);
                    }
                } catch (Exception e) {
                    // Skip malformed lines or trailing spaces
                    if (scanner.hasNextLine()) scanner.nextLine();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return products;
    }

    // NEW FEATURE: Add a new product to the list
    public void addProduct(Product newProduct) {
        try {
            // true means 'append' mode so we don't overwrite the whole file
            FileWriter fw = new FileWriter(fileName, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw);
            
            // Format matching your txt file: ID Name SellingPrice Qty SupplierID BoughtPrice Date
            out.printf(Locale.US, "\n%d %s %.2f %d %d %.2f %s", 
                newProduct.getId(), 
                newProduct.getName(), 
                newProduct.getSellingPrice(), 
                newProduct.getQuantity(), 
                newProduct.getSupplierID(), 
                newProduct.getBoughtPrice(), 
                newProduct.getBoughtDate().toFileDate());
            
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void updateProduct(Product product){
        try{
            ArrayList<Product> products = getProducts();
            for (Product product1 : products) {
                if(product.getId() == product1.getId()){
                    product1.setQuantity(product.getQuantity());
                }
            }

            FileWriter fw = new FileWriter(fileName, false);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter writer = new PrintWriter(bw);
            writer.write("ID NAME SELLINGPRICE QUANTITY SUPPLIERID BOUGHTPRICE BOUGHTDATE");
            for(Product product1: products){
                writer.write("\n" + product1.getId() + " ");
                writer.write(product1.getName() + " ");
                writer.write(product1.getSellingPrice() + " ");
                writer.write(product1.getQuantity() + " ");
                writer.write(product1.getSupplierID() + " ");
                writer.write(product1.getBoughtPrice() + " ");
                writer.write(product1.getBoughtDate().toFileDate());
            }
            writer.close();
        }
        catch (Exception ex){
            ex.printStackTrace();
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
        }
    }

    public Product getProductByName(String filter) throws FileException {
        Product product = new Product();
        boolean productFound = false;
        try {
            Scanner scanner = new Scanner(new File(fileName)).useLocale(Locale.US);

            String line = scanner.nextLine();
            String data, boughtDate;
            int id, supplierId;
            double price;
            double boughtPrice;
            int quantity;

            while (scanner.hasNext()) {
                id = scanner.nextInt();
                data = scanner.next();
                price = scanner.nextDouble();
                quantity = scanner.nextInt();
                supplierId = scanner.nextInt();
                boughtPrice = scanner.nextDouble();
                boughtDate = scanner.next();
                if(data.equals(filter)){
                    setProductValues(product, id, data, price, quantity, supplierId, boughtPrice, new DateForFile(boughtDate));
                    productFound = true;
                    break;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
        }
        if(!productFound){
            throw new FileException("Product not in stock!");
        }
        return product;
    }

    public ArrayList<Product> getProducts() {
        ArrayList<Product> products = new ArrayList<>();
        try {
            Scanner scanner = new Scanner(new File(fileName)).useLocale(Locale.US);

            String line = scanner.nextLine();

            while (scanner.hasNext()) {
                Product product = new Product();
                setProductValues(product, Integer.parseInt(scanner.next()),
                        scanner.next(),  Double.parseDouble(scanner.next()), Integer.parseInt(scanner.next()),
                        Integer.parseInt(scanner.next()), Double.parseDouble(scanner.next()), new DateForFile(scanner.next()));
                products.add(product);
            }
        }
        catch (Exception ex) {
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
            ex.printStackTrace();
        }
        return products;
    }

    public ArrayList<Product> getProductsBySupplierID(int filter) throws FileException {
        ArrayList<Product> products = new ArrayList<>();
        boolean productFound = false;
        try {
            Scanner scanner = new Scanner(new File(fileName)).useLocale(Locale.US);

            String line = scanner.nextLine();
            String data;
            int id, supplierId;
            double price;
            double boughtPrice;
            int quantity;
            String boughtDate;

            while (scanner.hasNext()) {
                id = scanner.nextInt();
                data = scanner.next();
                price = scanner.nextDouble();
                quantity = scanner.nextInt();
                supplierId = scanner.nextInt();
                boughtPrice = scanner.nextDouble();
                boughtDate = scanner.next();

                Product product = new Product();
                if(supplierId == filter){
                    setProductValues(product, id, data, price, quantity, supplierId, boughtPrice, new DateForFile(boughtDate));
                    products.add(product);
                    productFound = true;
                }
            }
        } catch (Exception ex) {
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
            ex.printStackTrace();
        }
        if(!productFound){
            throw new FileException("Product not in stock!");
        }
        return products;
    }



    public Product getProductById(int filter) throws FileException {
        Product product = new Product();
        boolean productFound = false;
        try {
            Scanner scanner = new Scanner(new File(fileName)).useLocale(Locale.US);

            String line = scanner.nextLine();
            String data;
            int id, supplierId;
            double price;
            double boughtPrice;
            int quantity;
            String boughtDate;

            while (scanner.hasNext()) {
                id = scanner.nextInt();
                data = scanner.next();
                price = scanner.nextDouble();
                quantity = scanner.nextInt();
                supplierId = scanner.nextInt();
                boughtPrice = scanner.nextDouble();
                boughtDate = scanner.next();
                if(id == filter){
                    setProductValues(product, id, data, price, quantity, supplierId, boughtPrice, new DateForFile(boughtDate));
                    productFound = true;
                    break;
                }
            }
        } catch (Exception ex) {
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
        }
        if(!productFound){
            throw new FileException("Product not in stock!");
        }
        return product;
    }

    private void setProductValues(Product product, int id, String data,  double price, int quantity, int supplierId, double boughtPrice, DateForFile boughtDate) {
        product.setId(id);
        product.setName(data);
        product.setSellingPrice(price);
        product.setQuantity(quantity);
        product.setSupplierID(supplierId);
        product.setBoughtPrice(boughtPrice);
        product.setBoughtDate(boughtDate);
    }

}
