package com.fileoperations;

public class FileException extends Exception {
	
    public FileException(String message){
        super(message);
    }

}
