package com.fileoperations;

public class Employee {
	
	public static final int ADMINISTRATOR = 2;
    public static final int MANAGER = 1;
    public static final int PHARMACIST = 0;

    private String name = "";
    private String surname = "";
    private DateForFile birthday = null;
    private MobileNo mobileNo = null;
    private String email = "";
    private double salary = 0;
    private User user = null;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public DateForFile getBirthday() {
        return birthday;
    }

    public void setBirthday(DateForFile birthday) {
        this.birthday = birthday;
    }

    public MobileNo getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(MobileNo mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

}
