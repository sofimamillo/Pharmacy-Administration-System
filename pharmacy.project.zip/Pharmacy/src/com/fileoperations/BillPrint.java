package com.fileoperations;

import java.io.PrintWriter;
import java.util.ArrayList;

public class BillPrint {
	
	private static final String DESTINATION = "src\\other\\bills\\Bill";

    public static void printBill(Bill bill){
        int id = bill.getId();
        String pharmacist = bill.getPharmacist().getUsername();
        double totalPrice = bill.getTotalPrice();
        ArrayList<SoldProduct> products = bill.getProducts();
        bill.setcDate(new DateForFile());
        String fileName = DESTINATION + id;
        try {
            PrintWriter writer = new PrintWriter(fileName);
            writer.write("Pharmacist: " + pharmacist + " Date printed: " + bill.getcDate() + "\n");
            for (SoldProduct product : products) {
                String productText = "ID: " + product.getId() + "   Name:" + product.getName() + "    Price:" + product.getSellingPrice() + "   Quantity: " + product.getSoldQuantity() +
                        "    | " + product.getSellingPrice() * product.getSoldQuantity() + "\n";

                writer.write(productText);
            }
            writer.write("\n TOTAL : " + totalPrice);
            writer.write("\n Bill ID: " + id);
            writer.close();
        }
        catch (Exception ex){
            System.out.println(fileName + " not found!");
            ex.printStackTrace();
        }

    }

}
