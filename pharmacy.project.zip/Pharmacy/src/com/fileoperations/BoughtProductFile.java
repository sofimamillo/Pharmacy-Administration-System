package com.fileoperations;
import java.io.*;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class BoughtProductFile {
	
	private final String fileName = "boughtproduct.txt";

    // This method records a NEW supply/restock event
    public void saveBoughtProduct(BoughtProduct bp) {
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(fileName, true)))) {
            // ID NAME UNITCOST QUANTITY SUPPLIERID DATE
            out.printf(Locale.US, "%d %s %.2f %d %d %s\n", 
                bp.getId(), 
                bp.getName(), 
                bp.getBoughtPrice(), 
                bp.getBoughtQuantity(), 
                bp.getSupplierID(), 
                bp.getBoughtDate().toFileDate());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // This method is for the Revenue Report
    public ArrayList<BoughtProduct> getBoughtProductsByDate(String date1, String date2) {
        ArrayList<BoughtProduct> list = new ArrayList<>();
        File file = new File(fileName);
        if (!file.exists()) return list;

        try (Scanner scanner = new Scanner(file).useLocale(Locale.US)) {
            while (scanner.hasNext()) {
                BoughtProduct bp = new BoughtProduct();
                bp.setId(scanner.nextInt());
                bp.setName(scanner.next());
                bp.setBoughtPrice(scanner.nextDouble());
                bp.setBoughtQuantity(scanner.nextInt());
                bp.setSupplierID(scanner.nextInt());
                bp.setBoughtDate(new DateForFile(scanner.next()));

                String fileDate = bp.getBoughtDate().toFileDate();
                if (fileDate.compareTo(date1) >= 0 && fileDate.compareTo(date2) <= 0) {
                    list.add(bp);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}
