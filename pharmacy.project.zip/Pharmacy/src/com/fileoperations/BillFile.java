package com.fileoperations;

import java.io.*;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class BillFile {
	
	private static final String BILL_ID_FILE_NAME = "billid.txt";
    private static final String BILL_FILE_NAME = "bill.txt";
    private static int id;

    public static void saveBill(Bill bill){

        try{
            FileWriter fw = new FileWriter(BILL_FILE_NAME, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter writer = new PrintWriter(bw);

            writer.write("\n" + bill.getId() + " ");
            writer.write(bill.getPharmacist().getName() + " ");
            writer.write(bill.getTotalPrice() + " ");
            writer.write(bill.getNrItems() + " ");
            writer.write(bill.getcDate().toFileDate() + " ");

            writer.close();
        }
        catch (Exception ex){
            System.out.println(
                    "Unable to open file '" +
                            BILL_FILE_NAME + "'");
            ex.printStackTrace();
        }
    }

    public static int getCurrentBillID(){
        try {
            Scanner scanner = new Scanner(new File(BILL_ID_FILE_NAME)).useLocale(Locale.US);
            String line = scanner.nextLine();
            id = scanner.nextInt();
        }
        catch (Exception ex){
            ex.printStackTrace();
            System.out.println("No file found!");
        }
        return id;
    }

    public static void incrementBillID(){
        try{
            id++;
            PrintWriter writer = new PrintWriter(BILL_ID_FILE_NAME);
            writer.write("ID\n" + id);
            writer.close();
        }
        catch (Exception ex){
            System.out.println(
                    "Unable to open file '" +
                            BILL_ID_FILE_NAME + "'");
            ex.printStackTrace();
        }
    }

    public static ArrayList<Bill> getBills(){
        ArrayList<Bill> bills = new ArrayList<>();
        try {
            Scanner scanner = new Scanner(new File(BILL_FILE_NAME)).useLocale(Locale.US);

            String line = scanner.nextLine();

            while (scanner.hasNext()) {
                Bill bill = new Bill();
                bill.setId(scanner.nextInt());
                bill.setPharmacist(new UserFile().getUserByName(scanner.next()));
                bill.setTotalPrice(scanner.nextDouble());
                bill.setNrItems(scanner.nextInt());
                bill.setcDate(new DateForFile(scanner.next()));
                bills.add(bill);
            }
        }
        catch (Exception ex) {
            System.out.println(
                    "Unable to open file '" +
                            BILL_FILE_NAME + "'");
            ex.printStackTrace();
        }
        return bills;
    }
	
	

}
