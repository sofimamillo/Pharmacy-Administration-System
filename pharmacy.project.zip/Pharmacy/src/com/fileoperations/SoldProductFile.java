package com.fileoperations;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class SoldProductFile {
	
    private static final String FILE_NAME = "soldproduct.txt";

    public void saveSoldProduct(SoldProduct sp) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            bw.write(
                    sp.getId() + " " +
                    sp.getName() + " " +
                    sp.getSellingPrice() + " " +
                    sp.getBillID() + " " +
                    sp.getSoldQuantity() + " " +
                    sp.getSoldDate().toFileDate()
            );
            bw.newLine();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= READ ALL =================
    public ArrayList<SoldProduct> getSoldProducts() {
        ArrayList<SoldProduct> list = new ArrayList<>();
        try (Scanner sc = new Scanner(new File(FILE_NAME)).useLocale(Locale.US)) {

            if (!sc.hasNextLine()) return list; // empty file
            sc.nextLine(); // skip header

            while (sc.hasNext()) {
                SoldProduct sp = readOne(sc);
                list.add(sp);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public ArrayList<SoldProduct> getSoldProductsByDate(String d1, String d2) {
        ArrayList<SoldProduct> list = new ArrayList<>();
        try (Scanner sc = new Scanner(new File(FILE_NAME)).useLocale(Locale.US)) {

            if (!sc.hasNextLine()) return list;
            sc.nextLine(); 

            while (sc.hasNext()) {
                SoldProduct sp = readOne(sc);
                String date = sp.getSoldDate().toFileDate();

                if (date.compareTo(d1) >= 0 && date.compareTo(d2) <= 0) {
                    list.add(sp);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    private SoldProduct readOne(Scanner sc) {
        SoldProduct sp = new SoldProduct();
        sp.setId(sc.nextInt());
        sp.setName(sc.next());
        sp.setSellingPrice(sc.nextDouble());
        sp.setBillID(sc.nextInt());
        sp.setSoldQuantity(sc.nextInt());
        try {
			sp.setSoldDate(new DateForFile(sc.next()));
		} catch (Exception e) {
			e.printStackTrace();
		}
        return sp;
    }

}
