package com.fileoperations;

public class Model {
	public static final int MINUS_ONE = -1;
    private int id = -1;
    private String description = "";
    private DateForFile cDate;

    public Model() {
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public DateForFile getcDate() {
        if (this.cDate == null) {
            this.cDate = new DateForFile();
        }

        return this.cDate;
    }

    public void setcDate(DateForFile cDate) {
        this.cDate = cDate;
    }

}
