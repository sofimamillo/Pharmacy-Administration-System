package com.fileoperations;
import java.util.ArrayList;


public class Bill extends Model {
	
	private User pharmacist;
    private ArrayList<SoldProduct> products = null;
    private int nrItems = 0;
    private double totalPrice = 0;

    public User getPharmacist() {
        return pharmacist;
    }

    public void setPharmacist(User pharmacist) {
        this.pharmacist = pharmacist;
    }

    public ArrayList<SoldProduct> getProducts() {
        if(products == null){
            products = new ArrayList<SoldProduct>();
        }
        return products;
    }

    public void setProducts(ArrayList<SoldProduct> products) {
        this.products = products;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getNrItems() {
        return nrItems;
    }

    public void setNrItems(int nrItems) {
        this.nrItems = nrItems;
    }

}
