package com.fileoperations;
import java.util.ArrayList;

public interface ProductFileInterface {
	
    public void updateProduct(Product product);
    public  Product getProductByName(String filter) throws FileException;
    public ArrayList<Product> getProducts();
    public ArrayList<Product> getProductsByDate(String date1, String date2);

}
