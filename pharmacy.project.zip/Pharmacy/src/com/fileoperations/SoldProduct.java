package com.fileoperations;

public class SoldProduct extends Product {
	
    private int billID = MINUS_ONE;
    private int soldQuantity = 0;
    private DateForFile soldDate = null;
    private double soldPrice;

    public int getBillID() {
        return billID;
    }
    public void setBillID(int billID) {
        this.billID = billID;
    }

    public DateForFile getSoldDate() {
        return soldDate;
    }

    public void setSoldDate(DateForFile soldDate) {
        this.soldDate = soldDate;
    }

    public int getSoldQuantity() {
        return soldQuantity;
    }

    public void setSoldQuantity(int soldQuantity) {
        this.soldQuantity = soldQuantity;
    }
	public double getSoldPrice() {
		return soldPrice;
	}
	public void setSoldPrice(double soldPrice) {
		this.soldPrice = soldPrice;
	}
    
    
	

}
