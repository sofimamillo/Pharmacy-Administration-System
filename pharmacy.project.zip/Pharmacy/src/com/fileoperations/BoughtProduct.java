package com.fileoperations;

public class BoughtProduct extends Product {
	
	   private int supplierID = MINUS_ONE;
	   private DateForFile boughtDate = null;
	    private int boughtQuantity; // To track how many were bought in THIS specific order

	    public BoughtProduct() {
	        super();
	    }

	    // Useful constructor for your ManagerSelectHandle logic
	    public BoughtProduct(int id, String name, double unitCost, int qty, int supplierID, DateForFile date) {
	        this.setId(id);
	        this.setName(name);
	        this.setBoughtPrice(unitCost); // From parent Product
	        this.boughtQuantity = qty;
	        this.supplierID = supplierID;
	        this.boughtDate = date;
	    }

	    public int getBoughtQuantity() {
	        return boughtQuantity;
	    }

	    public void setBoughtQuantity(int boughtQuantity) {
	        this.boughtQuantity = boughtQuantity;
	    }

	    @Override
	    public int getSupplierID() {
	        return supplierID;
	    }

	    @Override
	    public void setSupplierID(int supplierID) {
	        this.supplierID = supplierID;
	    }

	    public DateForFile getBoughtDate() {
	        return boughtDate;
	    }

	    public void setBoughtDate(DateForFile boughtDate) {
	        this.boughtDate = boughtDate;
	    }
	}

