package com.fileoperations;


public class Product extends Model {

	private String name = "";
    private int supplierID = MINUS_ONE;
    private DateForFile purchasedDate = null;
    private double purchasedPrice = 0;
    private int quantity = 0;
    private double sellingPrice = 0;
    private double boughtPrice = 0;
    private DateForFile boughtDate = null;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(int supplierID) {
        this.supplierID = supplierID;
    }

    public DateForFile getPurchasedDate() {
        return purchasedDate;
    }

    public void setPurchasedDate(DateForFile purchasedDate) {
        this.purchasedDate = purchasedDate;
    }

    public double getPurchasedPrice() {
        return purchasedPrice;
    }

    public void setPurchasedPrice(double purchasedPrice) {
        this.purchasedPrice = purchasedPrice;
    }

    public DateForFile getBoughtDate() {
        return boughtDate;
    }

    public void setBoughtDate(DateForFile boughtDate) {
        this.boughtDate = boughtDate;
    }

    public double getSellingPrice() {
        return sellingPrice;
    }

    public void setSellingPrice(double sellingPrice) {
        this.sellingPrice = sellingPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getBoughtPrice() {
        return boughtPrice;
    }

    public void setBoughtPrice(double boughtPrice) {
        this.boughtPrice = boughtPrice;
    }
}
