package com.fileoperations;
import java.io.*;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class UserFile {
	
	private final String fileName = "user.txt" ;

    public void deleteUser(User user){
        try{
            ArrayList<User> users = getUsers();
            for (User user1 : users) {
                if(user.getName().equals(user1.getName())){
                    users.remove(user);
                    break;
                }
            }

            FileWriter fw = new FileWriter(fileName, false);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter writer = new PrintWriter(bw);
            writer.write("NAME USERNAME PASSWORD ACCESSLEVEL SOLDBILLS SOLDITEMS MONEY BIRTHDAY MOBILENO EMAIL SALARY\n");
            for(User user1: users){
                writer.write("\n" + user1.getName() + " ");
                writer.write(user1.getUsername() + " ");
                writer.write(user1.getPassword() + " ");
                writer.write(user1.getAccessLevel() + " ");
                writer.write(user1.getSoldBills() + " ");
                writer.write(user1.getSoldItems() + " ");
                writer.write(user1.getMoney() + " ");
                writer.write(user1.getBirthday().toFileDate() + " ");
                writer.write(user1.getMobileNo() + " ");
                writer.write(user1.getEmail() + " ");
                writer.write(user1.getSalary() + " ");
            }
            writer.close();
        }
        catch (Exception ex){
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
        }
    }

    public void updateUser(User user){
        try{
            ArrayList<User> users = getUsers();
            for (User user1 : users) {
                if(user.getName().equals(user1.getName())){
                    user1.setBirthday(user.getBirthday());
                    user1.setAccessLevel(user.getAccessLevel());
                    user1.setEmail(user.getEmail());
                    user1.setMobileNo(user.getMobileNo());
                    user1.setSalary(user.getSalary());
                }
            }

            FileWriter fw = new FileWriter(fileName, false);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter writer = new PrintWriter(bw);
            writer.write("NAME USERNAME PASSWORD ACCESSLEVEL SOLDBILLS SOLDITEMS MONEY BIRTHDAY MOBILENO EMAIL SALARY\n");
            for(User user1: users){
                writer.write("\n" + user1.getName() + " ");
                writer.write(user1.getUsername() + " ");
                writer.write(user1.getPassword() + " ");
                writer.write(user1.getAccessLevel() + " ");
                writer.write(user1.getSoldBills() + " ");
                writer.write(user1.getSoldItems() + " ");
                writer.write(user1.getMoney() + " ");
                writer.write(user1.getBirthday().toFileDate() + " ");
                writer.write(user1.getMobileNo() + " ");
                writer.write(user1.getEmail() + " ");
                writer.write(user1.getSalary() + " ");
            }
            writer.close();
        }
        catch (Exception ex){
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
        }
    }

    public ArrayList<User> getUsers() {
        ArrayList<User> users = new ArrayList<>();
        try {
            Scanner scanner = new Scanner(new File(fileName)).useLocale(Locale.US);

            String line = scanner.nextLine();
            while (scanner.hasNext()) {
                User user = new User();
                user.setName(scanner.next());
                user.setUsername(scanner.next());
                user.setPassword(scanner.next());
                user.setAccessLevel(scanner.nextInt());
                user.setSoldBills(scanner.nextInt());
                user.setSoldItems(scanner.nextInt());
                user.setMoney(scanner.nextDouble());
                user.setBirthday(new DateForFile(scanner.next()));
                user.setMobileNo(scanner.next());
                user.setEmail(scanner.next());
                user.setSalary(scanner.nextDouble());
                users.add(user);
            }
        }
        catch (Exception ex) {
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
            ex.printStackTrace();
        }
        return users;
    }

    public void saveUser(User user){

        try{
            FileWriter fw = new FileWriter(fileName, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter writer = new PrintWriter(bw);

            writer.write("\n" + user.getName() + " ");
            writer.write(user.getUsername() + " ");
            writer.write(user.getPassword() + " ");
            writer.write(user.getAccessLevel() + " ");
            writer.write(user.getSoldBills() + " ");
            writer.write(user.getSoldItems() + " ");
            writer.write(user.getMoney() + " ");
            writer.write(user.getBirthday().toFileDate() + " ");
            writer.write(user.getMobileNo() + " ");
            writer.write(user.getEmail() + " ");
            writer.write(user.getSalary() + " ");

            writer.close();
        }
        catch (Exception ex){
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
            ex.printStackTrace();
        }
    }

        public User getUserByUsername(String filter) throws FileException {
        User user = new User();
        boolean userFound = false;
        try {
            Scanner scanner = new Scanner(new File(fileName)).useLocale(Locale.US);

            String line = scanner.nextLine();
            String name, username, password;
            int accessLevel, soldBills, soldItems;
            double money;
            String birthday, mobileNo, email;
            double salary;

            while (scanner.hasNext()) {
                name = scanner.next();
                username = scanner.next();
                password = scanner.next();
                accessLevel = scanner.nextInt();
                soldBills = scanner.nextInt();
                soldItems = scanner.nextInt();
                money = scanner.nextDouble();
                birthday = scanner.next();
                mobileNo = scanner.next();
                email = scanner.next();
                salary = scanner.nextDouble();
                if(username.equals(filter)){
                    user.setName(name);
                    user.setUsername(username);
                    user.setPassword(password);
                    user.setAccessLevel(accessLevel);
                    user.setSoldBills(soldBills);
                    user.setSoldItems(soldItems);
                    user.setMoney(money);
                    user.setBirthday(new DateForFile(birthday));
                    user.setMobileNo(mobileNo);
                    user.setEmail(email);
                    user.setSalary(salary);
                    userFound = true;
                    break;
                }
            }
        } catch (Exception ex) {
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
            ex.printStackTrace();
        }
        if(!userFound){
            throw new FileException("User does not exist!");
        }
        return user;
    }

    public User getUserByName(String filter) throws FileException {
        User user = new User();
        boolean userFound = false;
        try {
            Scanner scanner = new Scanner(new File(fileName)).useLocale(Locale.US);

            String line = scanner.nextLine();
            String name, username, password;
            int accessLevel, soldBills, soldItems;
            double money;
            String birthday, mobileNo, email;
            double salary;


            while (scanner.hasNext()) {
                name = scanner.next();
                username = scanner.next();
                password = scanner.next();
                accessLevel = scanner.nextInt();
                soldBills = scanner.nextInt();
                soldItems = scanner.nextInt();
                money = scanner.nextDouble();
                birthday = scanner.next();
                mobileNo = scanner.next();
                email = scanner.next();
                salary = scanner.nextDouble();
                if(name.equals(filter)){
                    user.setName(name);
                    user.setUsername(username);
                    user.setPassword(password);
                    user.setAccessLevel(accessLevel);
                    user.setSoldBills(soldBills);
                    user.setSoldItems(soldItems);
                    user.setMoney(money);
                    user.setBirthday(new DateForFile(birthday));
                    user.setMobileNo(mobileNo);
                    user.setEmail(email);
                    user.setSalary(salary);
                    userFound = true;
                    break;
                }
            }
        } catch (Exception ex) {
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
            ex.printStackTrace();
        }
        if(!userFound){
            user = null;
        }

        return user;
    }

}
