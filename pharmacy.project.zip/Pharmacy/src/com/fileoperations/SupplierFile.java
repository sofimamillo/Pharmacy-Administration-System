package com.fileoperations;
import java.io.File;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class SupplierFile {
	
	private final String fileName = "supplier.txt";

    public Supplier getSupplierByName(String filter) throws FileException {
        Supplier supplier = new Supplier();
        boolean productFound = false;
        try {
            Scanner scanner = new Scanner(new File(fileName)).useLocale(Locale.US);

            String line = scanner.nextLine();
            String name, mobile;
            int id;

            while (scanner.hasNext()) {
                id = scanner.nextInt();
                name = scanner.next();
                mobile = scanner.next();
                if(name.equals(filter)){
                    supplier.setId(id);
                    supplier.setName(name);
                    supplier.setMobileNo(mobile);
                    productFound = true;
                    break;
                }
            }
        } catch (Exception ex) {
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
            ex.printStackTrace();
        }
        if(!productFound){
            throw new FileException("Product not in stock!");
        }
        return supplier;
    }

    public ArrayList<Supplier> getSuppliers() {
        ArrayList<Supplier> suppliers = new ArrayList<>();
        try {
            Scanner scanner = new Scanner(new File(fileName)).useLocale(Locale.US);

            String line = scanner.nextLine();

            while (scanner.hasNext()) {
                Supplier supplier = new Supplier();
                supplier.setId(Integer.parseInt(scanner.next()));
                supplier.setName(scanner.next());
                supplier.setMobileNo(scanner.next());
                suppliers.add(supplier);
            }
        }
        catch (Exception ex) {
            System.out.println(
                    "Unable to open file '" +
                            fileName + "'");
            ex.printStackTrace();
        }
        return suppliers;
    }

}
