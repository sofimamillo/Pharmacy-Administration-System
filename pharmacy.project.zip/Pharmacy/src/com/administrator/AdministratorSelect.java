package com.administrator;
import com.fileoperations.DateForFile;
import com.fileoperations.ProductFile;
import com.fileoperations.SoldProductFile;
import com.fileoperations.UserFile;
import com.manager.AlertJavaFX;
import com.pharmacist.PharmacistMenuJavaFX;
import com.manager.ManagerSelectJavaFX;
import com.fileoperations.Employee;
import com.fileoperations.User;
import com.fileoperations.Product;
import com.fileoperations.SoldProduct;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.util.ArrayList;

public class AdministratorSelect {
	 public static void handleCalculateButtonOnAction(Button cancelButton, TextField date1, TextField date2, Label label1, Label label2){
	        cancelButton.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                ArrayList<SoldProduct> sold = new SoldProductFile().getSoldProductsByDate(date1.getText(), date2.getText());
	                ArrayList<Product> products = new ProductFile().getProductsByDate(date1.getText(), date2.getText());
	                double income = 0;
	                double cost = 0;
	                for(int i = 0 ; i < sold.size(); i++){
	                    income += sold.get(i).getSellingPrice();
	                }
	                for(int i = 0 ; i < products.size(); i++){
	                    cost += products.get(i).getBoughtPrice();
	                }
	                label1.setText("Total Income: " + income);
	                label2.setText("Total Cost: " + cost);
	            }
	        });
	    }

	    public static void handleRegisterButtonOnAction(Button registerButton, TextField nameTf, TextField birthdayTf, TextField phoneTf, TextField emailTf, TextField salaryTf, TextField accessLevelTf) {
	        registerButton.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                try {
	                    User user = new UserFile().getUserByName(nameTf.getText());
	                    if (user == null) {
	                        user = new User();
	                        user.setName(nameTf.getText());
	                        user.setBirthday(new DateForFile(birthdayTf.getText()));
	                        user.setMobileNo(phoneTf.getText());
	                        user.setEmail(emailTf.getText());
	                        user.setSalary(Double.parseDouble(salaryTf.getText()));
	                        checkAccessLevel(user, accessLevelTf);
	                        user.setUsername(nameTf.getText());
	                        user.setPassword("admin");
	                        new UserFile().saveUser(user);
	                        AlertJavaFX.showAlertMessage("Success", "Account was created with password 'admin' !");
	                    } else {
	                        AlertJavaFX.showAlertMessage("Error", "Account already exists!");
	                    }
	                } catch (Exception ex) {
	                    System.out.println(ex.getMessage());
	                }
	            }
	        });
	    }

	    private static void checkAccessLevel(User user, TextField accessLevelTf) {
	        if (accessLevelTf.getText().equals("ADMINISTRATOR")) {
	            user.setAccessLevel(2);
	        } else if (accessLevelTf.getText().equals("MANAGER")) {
	            user.setAccessLevel(1);
	        } else {
	            user.setAccessLevel(0);
	        }
	    }

	    public static void handleModifyButtonOnAction(Button modifyButton, TextField nameTf, TextField birthdayTf, TextField phoneTf, TextField emailTf, TextField salaryTf, TextField accessLevelTf) {
	        modifyButton.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                try {
	                    User user = new UserFile().getUserByName(nameTf.getText());
	                    if (user == null) {
	                        AlertJavaFX.showAlertMessage("Error", "Name of the user cannot be modified!");
	                    } else {
	                        user = new User();
	                        user.setName(nameTf.getText());
	                        user.setBirthday(new DateForFile(birthdayTf.getText()));
	                        user.setMobileNo(phoneTf.getText());
	                        user.setEmail(emailTf.getText());
	                        user.setSalary(Double.parseDouble(salaryTf.getText()));
	                        checkAccessLevel(user, accessLevelTf);
	                        user.setUsername(nameTf.getText());
	                        user.setPassword("admin");
	                        new UserFile().updateUser(user);
	                        AlertJavaFX.showAlertMessage("Success", "Account modified !");
	                    }
	                } catch (Exception ex) {
	                    System.out.println(ex.getMessage());
	                }
	            }
	        });
	    }

	    public static void handleDeleteButtonOnAction(Button modifyButton, TextField nameTf, TextField birthdayTf, TextField phoneTf, TextField emailTf, TextField salaryTf, TextField accessLevelTf, User user, Stage stage) {
	        modifyButton.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                try {
	                    User user = new UserFile().getUserByName(nameTf.getText());

	                    user = new User();
	                    user.setName(nameTf.getText());
	                    new UserFile().deleteUser(user);
	                    AlertJavaFX.showAlertMessage("Success", "Account deleted !");
	                    new AdministratorJavaFX(user).start();
	                    stage.close();
	                } catch (Exception ex) {
	                    System.out.println(ex.getMessage());
	                }
	            }
	        });
	    }

	    public static void handleEmployeesComboBxOnAction(ComboBox<String> employeesComboBox, TextField nameTf, TextField birthdayTf, TextField phoneTf, TextField emailTf, TextField salaryTf, TextField accessLevelTf) {
	        employeesComboBox.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                try {
	                    String employeeName = employeesComboBox.getValue();
	                    User user = new UserFile().getUserByName(employeeName);
	                    nameTf.setText(user.getName());
	                    birthdayTf.setText(user.getBirthday().toFileDate());
	                    phoneTf.setText(user.getMobileNo());
	                    emailTf.setText(user.getEmail());
	                    salaryTf.setText(user.getSalary() + "");
	                    if (user.getAccessLevel() == Employee.ADMINISTRATOR) {
	                        accessLevelTf.setText("ADMINISTRATOR");
	                    }
	                    if (user.getAccessLevel() == Employee.PHARMACIST) {
	                        accessLevelTf.setText("PHARMACIST");
	                    }
	                    if (user.getAccessLevel() == Employee.MANAGER) {
	                        accessLevelTf.setText("MANAGER");
	                    }

	                } catch (Exception ex) {
	                    System.out.println(ex.getMessage());
	                }
	            }
	        });
	    }

	    public static void handleAdministratorButtonOnAction(Button administratorButton, Stage stage, User user) {
	        administratorButton.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                stage.close();
	                new AdministratorJavaFX(user).start();
	            }
	        });
	    }

	    public static void handlePharmacistButtonOnAction(Button pharmacistButton, Stage stage, User user) {
	        pharmacistButton.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                stage.close();
	                new PharmacistMenuJavaFX(user).start();
	            }
	        });
	    }

	    public static void handleManagerButtonOnAction(Button managerButton, Stage stage, User user) {
	        managerButton.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                stage.close();
	                new ManagerSelectJavaFX(user).start();
	            }
	        });
	    }
	

}
