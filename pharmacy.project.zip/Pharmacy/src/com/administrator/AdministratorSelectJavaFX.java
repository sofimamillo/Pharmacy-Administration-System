package com.administrator;
import com.manager.PharmacistJavaFXAbstract;
import com.fileoperations.User;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AdministratorSelectJavaFX extends PharmacistJavaFXAbstract {
	
	 private User user = null;
	    private Stage stage = null;

	    public AdministratorSelectJavaFX(User user){
	        this.user = user;
	    }

	    public void start(){
	        stage = new Stage();
	        GridPane pane = new GridPane();
	        pane.setStyle("-fx-background-color: #8de4ff");
	        pane.setAlignment(Pos.CENTER);
	        pane.setHgap(10);
	        pane.setVgap(10);
	        pane.setPadding(new Insets(25, 25, 25, 25));
	        pane.setAlignment(Pos.CENTER);

	        pane.add(getUserMenu(), 0, 0);

	        stage.setTitle("Administrator");
	        stage.setScene(new Scene(pane, 800, 350));
	        stage.show();
	    }

	    public HBox getUserMenu(){
	        HBox vBox = new HBox(20);

	        vBox.setStyle("-fx-background-color: #8de4ff");

	        Button pharmacistButton = new Button("Pharmacist");
	        pharmacistButton.setStyle("-fx-background-color: #86ff46");
	        Button managerButton = new Button("Manager");
	        managerButton.setStyle("-fx-background-color: #ffddab");
	        Button administratorButton = new Button("Administrator");
	        administratorButton.setStyle("-fx-background-color: #ff71c5");
	        pharmacistButton.setMinSize(200, 100);
	        managerButton.setMinSize(200, 100);
	        administratorButton.setMinSize(200, 100);

	        AdministratorSelect.handleAdministratorButtonOnAction(administratorButton, stage, user);
	        AdministratorSelect.handlePharmacistButtonOnAction(pharmacistButton, stage, user);
	        AdministratorSelect.handleManagerButtonOnAction(managerButton, stage, user);

	        vBox.getChildren().addAll(pharmacistButton, managerButton, administratorButton);

	        return vBox;
	    }

	    public User getUser() {
	        return user;
	    }

	    public void setUser(User user) {
	        this.user = user;
	    }
	

}
