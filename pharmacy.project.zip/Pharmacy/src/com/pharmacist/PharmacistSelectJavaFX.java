package com.pharmacist;
import com.fileoperations.DateForFile;
import com.manager.AlertJavaFX;
import com.administrator.LoginJavaFX;
import com.fileoperations.Bill;
import com.fileoperations.BillPrint;
import com.fileoperations.BillFile;
import com.fileoperations.User;
import com.fileoperations.FileException;
import com.fileoperations.Product;
import com.fileoperations.SoldProduct;
import com.fileoperations.ProductFile;
import com.fileoperations.SoldProductFile;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

import java.util.ArrayList;

public class PharmacistSelectJavaFX {
	
	 private ComboBox<String> names = null;
	    private ArrayList<SoldProduct> soldProducts = new ArrayList<>();
	    private ArrayList<Product> products = new ArrayList<>();
	    private TextField id = null;
	    private TextField quantityTf = null;
	    private String name = null;
	    int row = 0;

	    public void handleCancelButton(Button cancel, User user, Stage stage){
	        cancel.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                    new PharmacistMenuJavaFX(user).start();
	                    stage.close();
	            }
	        });
	    }

	    public void handleOkButtonOnAction(Button ok, int id, User pharmacist, Stage stage){
	        ok.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                try {
	                    if (soldProducts.isEmpty()) {
	                        new AlertJavaFX().showAlertMessage("Error", "No products added to the bill!");
	                        return;
	                    }

	                    double totalPrice = 0;
	                    SoldProductFile soldFile = new SoldProductFile();
	                    ProductFile prodFile = new ProductFile();

	                    for(int i = 0 ; i < soldProducts.size(); i++){
	                        SoldProduct sProduct = soldProducts.get(i);
	                        Product originalProduct = products.get(i);

	                        // Set final transaction details
	                        sProduct.setBillID(id);
	                        sProduct.setSoldDate(new DateForFile());
	                        
	                        // Save to soldproduct.txt
	                        soldFile.saveSoldProduct(sProduct);
	                        
	                        // Calculate Running Total
	                        totalPrice += sProduct.getSellingPrice() * sProduct.getSoldQuantity();
	                        
	                        // Update Inventory (Subtract stock)
	                        originalProduct.setQuantity(originalProduct.getQuantity() - sProduct.getSoldQuantity());
	                        prodFile.updateProduct(originalProduct);
	                    }

	                    // Finalize bill
	                    Bill finalBill = getBill(totalPrice, id, pharmacist);
	                    BillPrint.printBill(finalBill);
	                    BillFile.saveBill(finalBill);
	                    BillFile.incrementBillID();

	                    AlertJavaFX.showAlertMessage("Success", "Bill NO " + id + " printed successfully.");
	                    stage.close();
	                    new PharmacistMenuJavaFX(pharmacist).start();
	                }
	                catch(Exception e){
	                    e.printStackTrace();
	                }
	            }
	        });
	    }

	    private Bill getBill(double totalPrice, int id, User pharmacist) {
	        Bill bill = new Bill();
	        bill.setProducts(soldProducts);
	        bill.setNrItems(soldProducts.size());
	        bill.setTotalPrice(totalPrice);
	        bill.setId(id);
	        bill.setPharmacist(pharmacist);
	        bill.setcDate(new DateForFile());
	        return bill;
	    }

	    public void handleAddButtonOnAction(Button add, GridPane menu, TextField totalTf){
	        add.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent event) {
	                SoldProduct soldProduct = new SoldProduct();
	                try {
	                    Product product = new ProductFile().getProductByName(name);
	                    if (name == null) {
	                        throw new Exception("No product entered!");
	                    }
	                    if(product.getQuantity() < Integer.parseInt(quantityTf.getText())){
	                        new AlertJavaFX().showAlertMessage("Error", "There are not enough products in stock!");
	                    }
	                    else{
	                        setSoldProductValues(soldProduct, product);
	                        int i = Integer.parseInt(quantityTf.getText());
	                        soldProduct.setSoldQuantity(i);
	                        addProductToMenu(soldProduct, menu);
	                        soldProducts.add(soldProduct);
	                        products.add(product);

	                        double totalValue = Double.parseDouble(totalTf.getText()) + soldProduct.getSellingPrice() * soldProduct.getSoldQuantity();
	                        totalTf.setText(totalValue + "");
	                    }
	                }
	                catch(Exception e){
	                    System.out.println(e.getMessage());
	                }

	            }
	        });
	    }

	    private void addProductToMenu(SoldProduct soldProduct, GridPane menu) {

	        Label idLabel = new Label(soldProduct.getId() + "");
	        idLabel.setMinHeight(20);
	        idLabel.setPadding(new Insets(0, 0, 0, 70));
	        menu.add(idLabel, 0, row);

	        Label nameLabel = new Label(soldProduct.getName());
	        nameLabel.setMinHeight(20);
	        nameLabel.setPadding(new Insets(0, 0, 0, 20));
	        menu.add(nameLabel, 1, row);

	        Label priceLabel = new Label(soldProduct.getSellingPrice() + "");
	        priceLabel.setMinHeight(20);
	        priceLabel.setPadding(new Insets(0, 0, 0, 36));
	        menu.add(priceLabel, 2, row);


	        Label quantityLabel = new Label(soldProduct.getSoldQuantity() + "");
	        quantityLabel.setMinHeight(20);
	        quantityLabel.setPadding(new Insets(0, 0, 0, 36));
	        menu.add(quantityLabel, 3, row);
	        row++;
	    }

	    private void setSoldProductValues(SoldProduct soldProduct, Product product) {
	        soldProduct.setId(product.getId());
	        soldProduct.setName(product.getName());
	        soldProduct.setSellingPrice(product.getSellingPrice());
	        soldProduct.setBillID(BillFile.getCurrentBillID());


	    }


	    public static void handleLogOutButtonOnAction(Button logOutButton, Stage primaryStage){
	        logOutButton.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent e) {
	                primaryStage.close();
	                new LoginJavaFX().start();
	            }
	        });
	    }

	    public void handleNamesOnAction(){
	        names.setOnAction((event) -> {

	            name = names.getValue();
	            try {
	                Product product = new ProductFile().getProductByName(name);
	                id.setText(String.valueOf(product.getId()));
	                quantityTf.setText("1");
	            }
	            catch (FileException e){
	                e.printStackTrace();
//	                System.out.println("Product not in files!");
	            }
	        });
	    }

	    public ComboBox<String> getNames() {
	        return names;
	    }

	    public void setNames(ComboBox<String> names) {
	        this.names = names;
	    }
	    public ArrayList<SoldProduct> getSoldProducts() {
	        return soldProducts;
	    }

	    public void setSoldProducts(ArrayList<SoldProduct> soldProducts) {
	        this.soldProducts = soldProducts;
	    }

	    public TextField getId() {
	        return id;
	    }

	    public void setId(TextField id) {
	        this.id = id;
	    }

	    public TextField getQuantityTf() {
	        return quantityTf;
	    }

	    public void setQuantityTf(TextField quantityTf) {
	        this.quantityTf = quantityTf;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public int getRow() {
	        return row;
	    }

	    public void setRow(int row) {
	        this.row = row;
	    }
	

}
