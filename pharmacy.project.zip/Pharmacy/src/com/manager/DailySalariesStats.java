package com.manager;
import com.fileoperations.DateForFile;
import com.fileoperations.Employee;

import java.util.ArrayList;

public class DailySalariesStats {
	
    private DateForFile date = null;
    private ArrayList<Employee> employees = null;

    public DateForFile getDate() {
        return date;
    }

    public void setDate(DateForFile date) {
        this.date = date;
    }

    public ArrayList<Employee> getEmployees() {
        if(employees == null){
            employees = new ArrayList<>();
        }
        return employees;
    }

    public void setEmployees(ArrayList<Employee> employees) {
        this.employees = employees;
    }

}
