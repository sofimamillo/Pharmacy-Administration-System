package com.manager;

import com.fileoperations.ProductFile;
import com.fileoperations.User;
import com.fileoperations.Product;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.util.ArrayList;

public class ManagerSelectJavaFX extends PharmacistJavaFXAbstract {
    private Stage primaryStage = null;
    private User user = null;
    private ManagerSelectHandle managerMenuGUI = new ManagerSelectHandle();

    public ManagerSelectJavaFX(User user){
        this.user = user;
    }

    public void start(){
        primaryStage = new Stage();
        GridPane gridPane = new GridPane();

        addHeaderToMainPane(gridPane, primaryStage, user);
        addMenuBarToMainPane(gridPane);

        gridPane.setStyle("-fx-background-color: #79f8ff");
        gridPane.setPadding(new Insets(20, 20, 20, 20));
        primaryStage.setTitle("Pharmacy / Pharmacist");
        primaryStage.setScene(new Scene(gridPane, 1000, 500));
        ArrayList<Product> products = new ProductFile().getProducts();
        String productNames = "";
        boolean alert = false;
        for(int i= 0 ;i < products.size(); i++){
            if(products.get(i).getQuantity() <= 5){
                productNames += products.get(i).getName() + ", ";
                alert = true;
            }
        }

        primaryStage.show();
        if(alert){
            AlertJavaFX.showAlertMessage("Attention", "Products: " + productNames + " have less than 5 items in stock!");
        }
    }

    private void addMenuBarToMainPane(GridPane gridPane){
        HBox hBox = new HBox();
        hBox.setPadding(new Insets(20,0,0,0));

        Button supplyButton = getMenuButton("Supply");
        supplyButton.setStyle("-fx-background-color: #86ff46");

        Button pharmacistButton = getMenuButton("Pharmacists");
        pharmacistButton.setStyle("-fx-background-color: #ffddab");

        Button productButton = getMenuButton("Products");
        productButton.setStyle("-fx-background-color: #ff71c5");


        managerMenuGUI.setMainPane(gridPane);
        managerMenuGUI.handleSupplyButtonOnAction(supplyButton);
        managerMenuGUI.handlePharmacistsButtonOnAction(pharmacistButton);
        managerMenuGUI.handleProductsButtonOnAction(productButton);

        hBox.getChildren().addAll(supplyButton, pharmacistButton, productButton);
        gridPane.add(hBox, 0, 1);
    }

    private Button getMenuButton(String text){
        Button button = new Button(text);
        button.setMinWidth(320);
        return button;
    }

}
