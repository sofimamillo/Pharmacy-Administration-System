package com.manager;
import com.fileoperations.DateForFile;
import com.fileoperations.BoughtProduct;

import java.util.ArrayList;

public class DailySupplyStats {
	
    private DateForFile date = null;
    private ArrayList<BoughtProduct> products = null;

    public ArrayList<BoughtProduct> getProducts() {
        if(products == null){
            products = new ArrayList<>();
        }
        return products;
    }

    public void setProducts(ArrayList<BoughtProduct> products) {
        this.products = products;
    }

    public DateForFile getDate() {
        return date;
    }

    public void setDate(DateForFile date) {
        this.date = date;
    }
}


