package com.manager;

import com.fileoperations.DateForFile;
import com.fileoperations.*;
import com.fileoperations.Bill;
import com.fileoperations.User;
import com.fileoperations.Product;
import com.fileoperations.SoldProduct;
import com.fileoperations.Supplier;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

import java.util.ArrayList;

public class ManagerSelectHandle {
    static GridPane mainPane = null;
    static GridPane supplyPane = new GridPane();
    static GridPane pharmacistPane = new GridPane();
    static GridPane productPane = new GridPane();


    public static void handleListButtonOnAction(Button listButton, ComboBox<String> productsSoldCombo, ComboBox<String> productsBoughtCombo, TextField firstTf, TextField secondTf, TextField revenueTf){
        listButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                double profit = fillSoldProductsComobBox(productsSoldCombo, firstTf, secondTf);
                double cost = fillBoughtProductsComboBox(productsBoughtCombo, firstTf, secondTf);
                double total = profit - cost;
                revenueTf.setText("Total revenue: " + total);
            }
        });
    }

    public static double fillBoughtProductsComboBox(ComboBox<String> productsBoughtCombo, TextField firstTf, TextField secondTf) {
        double res = 0;

        ArrayList<Product> boughtProducts = new ProductFile().getProductsByDate(firstTf.getText(), secondTf.getText());
        for (Product product: boughtProducts) {
            productsBoughtCombo.getItems().add(product.getName());
            res -= product.getBoughtPrice();
        }
        return res;
    }

    public static double fillSoldProductsComobBox(ComboBox<String> productsSoldCombo, TextField firstTf, TextField secondTf) {
        double res = 0;

        ArrayList<SoldProduct> soldProducts = new SoldProductFile().getSoldProductsByDate(firstTf.getText(), secondTf.getText());
        for (SoldProduct soldProduct: soldProducts) {
            productsSoldCombo.getItems().add(soldProduct.getName());
            res += soldProduct.getSoldQuantity();
        }
        return res;
    }

    public static void handleOkButtonPharmacistOnAction(Button okButton, ComboBox<String> pharmacistComboBox, TextField noBillsTf, TextField itemsSoldTf, TextField moneyTf, TextField firstDateTf, TextField secondDateTf){
        okButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    buttonComboBoxHandlerMethod(pharmacistComboBox, firstDateTf, secondDateTf, noBillsTf, itemsSoldTf, moneyTf);
                }catch (Exception ex){
                    System.out.println(ex.getMessage());
                }

            }
        });
    }

    public static void handlePharmacistComboBxOnAction(ComboBox<String> pharmacistComboBox, TextField noBillsTf, TextField itemsSoldTf, TextField moneyTf, TextField firstDateTf, TextField secondDateTf){
        pharmacistComboBox.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    buttonComboBoxHandlerMethod(pharmacistComboBox, firstDateTf, secondDateTf, noBillsTf, itemsSoldTf, moneyTf);
                }catch (Exception ex){
                    System.out.println(ex.getMessage());
                }

            }
        });
    }

    private static void buttonComboBoxHandlerMethod(ComboBox<String> pharmacistComboBox, TextField firstDateTf, TextField secondDateTf, TextField noBillsTf, TextField itemsSoldTf, TextField moneyTf) throws Exception {
        int noBills = 0, nrItems = 0;
        double totalPrice = 0;
        String userName = pharmacistComboBox.getValue();
        User user = new UserFile().getUserByName(userName);
        ArrayList<Bill> bills = BillFile.getBills();
        for (Bill bill : bills) {
            if(bill.getPharmacist().getName().equals(user.getName())){
                DateForFile firstDate = new DateForFile(firstDateTf.getText());
                DateForFile secondDate = new DateForFile(secondDateTf.getText());
                DateForFile billDate = bill.getcDate();
                int compareRes = billDate.toFileDate().compareTo(firstDate.toFileDate());
                int secondCompareRes = billDate.toFileDate().compareTo(secondDate.toFileDate());
                if(compareRes != -1){
                    if(secondCompareRes != 1){
                        noBills++;
                        nrItems += bill.getNrItems();
                        totalPrice += bill.getTotalPrice();
                    }
                }
            }
        }
        noBillsTf.setText(noBills + "");
        itemsSoldTf.setText(nrItems + "");
        moneyTf.setText(totalPrice + "");
    }

    public static void handleProductsButtonOnAction(Button productsButton){
        productsButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    removePreviousPanes();
                    productPane = ManagerProductJavaFX.getPane();
                    mainPane.add(productPane, 0, 2);
                }
                catch (Exception ex){
                    System.out.println(ex.getMessage());
                }
            }
        });
    }

    private static void removePreviousPanes() {
        mainPane.getChildren().remove(supplyPane);
        mainPane.getChildren().remove(pharmacistPane);
        mainPane.getChildren().remove(productPane);
    }

    public static void handlePharmacistsButtonOnAction(Button pharmacistButton){
        pharmacistButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    removePreviousPanes();
                    pharmacistPane = ManagerPharmacistJavaFX.getPane();
                    mainPane.add(pharmacistPane, 0, 2);
                }
                catch (Exception ex){
                    System.out.println(ex.getMessage());
                }
            }
        });
    }

    public static void handleSupplyButtonOnAction(Button supplyButton){
        supplyButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    removePreviousPanes();
                    supplyPane.setPadding(new Insets(50, 0, 50, 0));
                    supplyPane.add(ManagerSupplyJavaFX.getPane(), 0, 0);
                    supplyPane.add(ManagerSupplyJavaFX.getListOfProductPane(new ArrayList<>()), 1, 0);
                    mainPane.add(supplyPane, 0, 2);
                }
                catch (Exception ex){
                    System.out.println(ex.getMessage());
                }
            }
        });
    }

    public static void handleOkButtonOnAction(Button okButton, TextField idTf, TextField quantityTf){
        okButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    Product product = new ProductFile().getProductById(Integer.parseInt(idTf.getText()));
                    product.setQuantity(product.getQuantity() + Integer.parseInt(quantityTf.getText()));
                    new ProductFile().updateProduct(product);
                    AlertJavaFX.showAlertMessage("Success", "Successfully bought " + quantityTf.getText() + " items of " + product.getName() + "!");
                }
                catch (Exception ex){
                    AlertJavaFX.showAlertMessage("Error", "Please enter the right information!");
                    System.out.println(ex.getMessage());
                }
            }
        });
    }

    public static void handlePharmacistsComboOnAction(ComboBox<String> pharmacists){
        pharmacists.setOnAction((event) -> {
            try {
                String userName = pharmacists.getValue();
                User user = new UserFile().getUserByName(userName);

            }
            catch (Exception ex){
                System.out.println(ex.getMessage());
            }
        });
    }

    public static void handleSuppliersComboOnAction(ComboBox<String> suppliers){
        suppliers.setOnAction((event) -> {
            try {
                String supplierName = suppliers.getValue();
                Supplier supplier = new SupplierFile().getSupplierByName(supplierName);
                ArrayList<Product> products = new ProductFile().getProductsBySupplierID(supplier.getId());
                supplyPane.add(ManagerSupplyJavaFX.getPaneWithButtons(supplierName), 0, 0);
                supplyPane.add(ManagerSupplyJavaFX.getListOfProductPane(products), 1, 0);
                mainPane.add(supplyPane, 0, 2);
            }
            catch (Exception ex){
                System.out.println(ex.getMessage());
            }
        });
    }

    public GridPane getMainPane() {
        return mainPane;
    }

    public void setMainPane(GridPane mainPane) {
        this.mainPane = mainPane;
    }

    public GridPane getPharmacistPane() {
        return pharmacistPane;
    }

    public void setPharmacistPane(GridPane pharmacistPane) {
        this.pharmacistPane = pharmacistPane;
    }

    public static GridPane getProductPane() {
        return productPane;
    }

    public static void setProductPane(GridPane productPane) {
        ManagerSelectHandle.productPane = productPane;
    }
}
