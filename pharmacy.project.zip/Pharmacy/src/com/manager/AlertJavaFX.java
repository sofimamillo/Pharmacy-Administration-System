package com.manager;
import javafx.scene.control.Alert;

public class AlertJavaFX {
	
	public static void showAlertMessage(String title, String text) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(text);
        alert.showAndWait();
    }

}
