package com.manager;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import java.time.LocalDate;

public class ManagerProductJavaFX {
    private static DatePicker startDatePicker = null;
    private static DatePicker endDatePicker = null;
    private static ComboBox<String> productsBoughtCombo = null;
    private static ComboBox<String> productsSoldCombo = null;
    private static Button listButton = null;
    private static TextField revenueTf = null;

    public static GridPane getPane(){
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(15);
        gridPane.setPadding(new Insets(30));

        
        VBox header = new VBox(10);
        header.setAlignment(Pos.CENTER);
        
        listButton = new Button("GENERATE REVENUE REPORT");
        listButton.setMinWidth(450);
        listButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");

        HBox dateBox = new HBox(10);
        startDatePicker = new DatePicker(LocalDate.now().minusMonths(1)); // Default to last month
        endDatePicker = new DatePicker(LocalDate.now());
        startDatePicker.setMinWidth(220);
        endDatePicker.setMinWidth(220);
        dateBox.getChildren().addAll(startDatePicker, endDatePicker);
        
        header.getChildren().addAll(listButton, dateBox);

       
        HBox comboRow = new HBox(10);
        productsBoughtCombo = new ComboBox<>();
        productsBoughtCombo.setPromptText("Products Bought");
        productsBoughtCombo.setMinWidth(220);

        productsSoldCombo = new ComboBox<>();
        productsSoldCombo.setPromptText("Products Sold");
        productsSoldCombo.setMinWidth(220);
        comboRow.getChildren().addAll(productsSoldCombo, productsBoughtCombo);

     
        revenueTf = new TextField("Total revenue: $0.00");
        revenueTf.setEditable(false);
        revenueTf.setFont(new Font("System Bold", 24));
        revenueTf.setAlignment(Pos.CENTER);
        revenueTf.setMinHeight(80);

        gridPane.add(header, 0, 0);
        gridPane.add(comboRow, 0, 1);
        gridPane.add(revenueTf, 0, 2);

        listButton.setOnAction(e -> {
            TextField dummyStart = new TextField(startDatePicker.getValue().toString());
            TextField dummyEnd = new TextField(endDatePicker.getValue().toString());
            ManagerSelectHandle.handleListButtonOnAction(listButton, productsSoldCombo, productsBoughtCombo, dummyStart, dummyEnd, revenueTf);
        });

        return gridPane;
    }
}