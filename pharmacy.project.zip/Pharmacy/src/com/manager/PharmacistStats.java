package com.manager;
import com.fileoperations.Model;

import java.util.ArrayList;

public class PharmacistStats {
	
	private int EmployeeID = Model.MINUS_ONE;
    private ArrayList<DailyBillStats> billStats= null;

    public ArrayList<DailyBillStats> getBillStats() {
        if(billStats == null){
            billStats = new ArrayList<>();
        }
        return billStats;
    }

    public void setBillStats(ArrayList<DailyBillStats> billStats) {
        this.billStats = billStats;
    }

    public int getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(int employeeID) {
        EmployeeID = employeeID;
    }

}
