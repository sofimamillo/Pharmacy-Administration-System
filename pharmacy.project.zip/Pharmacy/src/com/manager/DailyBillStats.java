package com.manager;
import com.fileoperations.DateForFile;
import com.fileoperations.Bill;

import java.util.ArrayList;

public class DailyBillStats {
	
    private DateForFile date = null;
    private ArrayList<Bill> bills = null;

    public DateForFile getDate() {
        return date;
    }

    public void setDate(DateForFile date) {
        this.date = date;
    }

    public ArrayList<Bill> getBills() {
        return bills;
    }

    public void setBills(ArrayList<Bill> bills) {
        this.bills = bills;
    }

}
