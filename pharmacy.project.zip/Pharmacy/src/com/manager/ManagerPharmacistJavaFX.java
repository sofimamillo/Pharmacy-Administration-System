package com.manager;
import com.fileoperations.DateForFile;
import com.fileoperations.UserFile;
import com.fileoperations.User;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.util.ArrayList;

public class ManagerPharmacistJavaFX {
	
	private static TextField nrBillsTf = new TextField();
    private static TextField itemsSoldTf = new TextField();
    private static TextField moneyMadeTf = new TextField();
    private static TextField firstDateTf = null;
    private static TextField secondDateTf = null;
    private static ComboBox<String> pharmacistComboBox = null;

    public static GridPane getPane(){
        GridPane gridPane = new GridPane();

        setPharmacistComboBoxValues();
        gridPane.add(pharmacistComboBox, 0, 0);
        gridPane.add(getStats(), 0, 1);
        gridPane.add(getDateTextFields(), 0, 2);
        Button okButton = new Button("OK");
        okButton.setMinWidth(300);
        okButton.setAlignment(Pos.CENTER);
        gridPane.add(okButton, 0, 3);
        ManagerSelectHandle.handlePharmacistComboBxOnAction(pharmacistComboBox, nrBillsTf, itemsSoldTf, moneyMadeTf, firstDateTf, secondDateTf);
        ManagerSelectHandle.handleOkButtonPharmacistOnAction(okButton, pharmacistComboBox, nrBillsTf, itemsSoldTf, moneyMadeTf, firstDateTf, secondDateTf);


        gridPane.setVgap(10);
        gridPane.setHgap(10);
        gridPane.setPadding(new Insets(30, 0, 0, 0));

        return gridPane;
    }

    private static VBox getStats(){
        VBox vBox = new VBox(10);
        vBox.setPadding(new Insets(30,0,0,0));

        GridPane firstLine = new GridPane();
        Label billsLabel = new Label("No Bills: ");
        billsLabel.setMinWidth(120);
        billsLabel.setPadding(new Insets(0,0,0,30));
        firstLine.add(billsLabel, 0, 0);
        firstLine.add(nrBillsTf, 1, 0);

        GridPane secondLine = new GridPane();
        Label soldLabel = new Label("Items Sold: ");
        soldLabel.setMinWidth(120);
        soldLabel.setPadding(new Insets(0,0,0,30));
        secondLine.add(soldLabel, 0, 0);
        secondLine.add(itemsSoldTf, 1, 0);

        GridPane thirdLine = new GridPane();
        Label moneyLabel = new Label("Money Made: ");
        moneyLabel.setMinWidth(120);
        moneyLabel.setPadding(new Insets(0,0,0,30));
        thirdLine.add(moneyLabel, 0, 0);
        thirdLine.add(moneyMadeTf, 1, 0);
        vBox.getChildren().addAll(firstLine, secondLine, thirdLine);
        return vBox;
    }

    private static HBox getDateTextFields(){
        HBox hbox = new HBox(10);

        firstDateTf = new TextField(new DateForFile().toFileDate());
        secondDateTf = new TextField(new DateForFile().toFileDate());

        hbox.getChildren().addAll(firstDateTf, secondDateTf);
        hbox.setPadding(new Insets(20, 0,10, 0));
        return hbox;
    }

    private static void setPharmacistComboBoxValues(){
        pharmacistComboBox = new ComboBox<>();
        pharmacistComboBox.setStyle("-fx-background-color: #ffcaca");
        ArrayList<User> users = new UserFile().getUsers();

        pharmacistComboBox.setMinWidth(300);
        pharmacistComboBox.setValue("Pharmacists");

        for (User user: users) {
            if(user.getAccessLevel() == 0){
                pharmacistComboBox.getItems().add(user.getName());
            }
        }
    }

    public static TextField getNrBillsTf() {
        return nrBillsTf;
    }

    public static void setNrBillsTf(TextField nrBillsTf) {
        ManagerPharmacistJavaFX.nrBillsTf = nrBillsTf;
    }

    public static TextField getItemsSoldTf() {
        return itemsSoldTf;
    }

    public static void setItemsSoldTf(TextField itemsSoldTf) {
        ManagerPharmacistJavaFX.itemsSoldTf = itemsSoldTf;
    }

    public static TextField getMoneyMadeTf() {
        return moneyMadeTf;
    }

    public static void setMoneyMadeTf(TextField moneyMadeTf) {
        ManagerPharmacistJavaFX.moneyMadeTf = moneyMadeTf;
    }

}
